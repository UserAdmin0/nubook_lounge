<?php include 'config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Book Listings</title>
    <link rel="stylesheet" href="../frontend/styles.css">
</head>
<body>
<h1>Book List</h1>

<?php
$sql = "SELECT * FROM books ORDER BY created_at DESC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "<div class='book'>";
        echo "<h2>" . htmlspecialchars($row['title']) . "</h2>";
        echo "<p>Category: " . htmlspecialchars($row['category']) . "</p>";
        echo "<small>Added: " . $row['created_at'] . "</small>";
        echo "</div>";
    }
} else {
    echo "<p>No books available.</p>";
}
$conn->close();
?>
</body>
</html>
