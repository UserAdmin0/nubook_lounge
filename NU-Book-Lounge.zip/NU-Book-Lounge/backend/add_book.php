<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $category = $_POST['category'];

    $stmt = $conn->prepare("INSERT INTO books (title, category) VALUES (?, ?)");
    $stmt->bind_param("ss", $title, $category);

    if ($stmt->execute()) {
        echo "<p>✅ Book added successfully!</p>";
    } else {
        echo "<p>❌ Error: " . $stmt->error . "</p>";
    }
    $stmt->close();
}
$conn->close();
?>
