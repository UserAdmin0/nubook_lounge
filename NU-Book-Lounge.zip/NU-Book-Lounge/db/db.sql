CREATE DATABASE IF NOT EXISTS bookstore;
USE bookstore;

CREATE TABLE IF NOT EXISTS books (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  category VARCHAR(100) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO books (title, category) VALUES
('The Great Gatsby', 'Adults'),
('Harry Potter', 'Early Readers'),
('Economics 101', 'Economic'),
('World History', 'History'),
('Backpacking Europe', 'Travel');
